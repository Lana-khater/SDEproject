package mainANDcontrollers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.awt.event.ActionEvent;
import java.net.URL;
import java.util.ResourceBundle;

public class WandFabric {


    ObservableList<String> FabrictypeList2 = FXCollections.observableArrayList("Cotton","Synthetics","Others(delicates)");

    ObservableList<String> Fabriccolour2 = FXCollections.observableArrayList("White","Colours");

    @FXML private RadioButton yesbtn;
    @FXML private ToggleGroup yesorno;
    @FXML private RadioButton nobtn;
    @FXML private ComboBox fabricType;
    @FXML private ComboBox fabricColor;
    @FXML private Button NextButton;





    @FXML
    public void initialize() {
        fabricType.setValue("Cotton");
        fabricType.setItems(FabrictypeList2);


        fabricColor.setValue("Colours");
        fabricColor.setItems(Fabriccolour2);
    }



    public void NextpageOnAction(javafx.event.ActionEvent event) {
    }
}
