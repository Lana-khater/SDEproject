# SDEproject
Hello! 
This is the Zen4 self-service on-site Laundry program.


The app includes customer profiles with personal data such as a customer’s name, and phone number. The customer app enables users to:

-Sign up and log in
-Choose the type of service and add details (fabric, kinds of clothes, detergent preferences, etc.)
-Calculate the cost of service and pay on site
-Track time and get notifications 

