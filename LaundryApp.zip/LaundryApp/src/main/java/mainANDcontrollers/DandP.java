package mainANDcontrollers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class DandP {

   // @FXML private CheckBox Lowerbound;
   // @FXML private CheckBox Upperbound;
    @FXML private Button NextButton;
    @FXML private Label AnswerLabel;
    @FXML private RadioButton Lowerbound;
    @FXML private RadioButton Upperbound;
    @FXML private ToggleGroup UL;






    public void LowerboundOnAction(ActionEvent event) {
        AnswerLabel.setText("1000 FORINTS");
        //MORE IS ADDED LATER
    }

    public void UpperboundOnAction(ActionEvent event) {
       AnswerLabel.setText("1700 FORINTS");
        //MORE IS ADDED LATER
    }

    public void NextpageOnAction(ActionEvent event) {
        //WHEN THERE IS A NEXT PAGE
    }



}
